prog_a es quien envia los mensajes y prog_b es el que los recibe y muestra
